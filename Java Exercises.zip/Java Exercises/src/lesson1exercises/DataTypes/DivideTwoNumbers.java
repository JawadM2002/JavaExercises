package lesson1exercises.DataTypes;

public class DivideTwoNumbers {
	
	public static void main(String[] args) {
		int num1 = 50, num2 = 3, divi = 0;
		
		divi = num1 + num2;
		System.out.println(divi);
	}

}
