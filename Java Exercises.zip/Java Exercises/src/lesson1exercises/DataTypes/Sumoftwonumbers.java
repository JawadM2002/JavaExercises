package lesson1exercises.DataTypes; 

public class Sumoftwonumbers {

	public static void main(String[] args) {
		int num1 = 75, num2 = 36, sum = 0;
		
		sum = num1 + num2;
		System.out.println(sum);
		
	}
}
