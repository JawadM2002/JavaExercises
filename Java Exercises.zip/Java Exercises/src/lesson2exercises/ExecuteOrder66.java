package lesson2exercises;

import java.util.Scanner;

public class ExecuteOrder66 {

	public static void main(String[] args) {
		
		boolean Order66 = true;
		
		if (Order66 == false) {
			System.out.println("It's treason, then.");
		} else {
			System.out.println("Yes, my lord.");
		}
		

	}
	
}
