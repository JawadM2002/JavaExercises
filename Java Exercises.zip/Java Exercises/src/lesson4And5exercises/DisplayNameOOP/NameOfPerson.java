package lesson4And5exercises.DisplayNameOOP;

public class NameOfPerson {

	public void display() {
		System.out.println("Jawad Mahmud");

	}

}
