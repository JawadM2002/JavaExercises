package lesson4And5exercises.DisplayNameOOP;

public class DisplayName {

	public static void main(String[] args) {
		NameOfPerson name = new NameOfPerson();
		name.display();
	}

}
